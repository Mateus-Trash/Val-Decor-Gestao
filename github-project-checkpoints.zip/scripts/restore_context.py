#!/usr/bin/env python3
"""Restore project context from .project-memory/."""

from __future__ import annotations

import argparse
import subprocess
from pathlib import Path


def run(cmd: list[str], cwd: Path) -> tuple[int, str]:
    try:
        proc = subprocess.run(cmd, cwd=str(cwd), text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, check=False)
        return proc.returncode, proc.stdout.strip()
    except FileNotFoundError:
        return 127, f"command not found: {cmd[0]}"


def resolve_repo(path: Path) -> tuple[Path, bool]:
    code, out = run(["git", "rev-parse", "--show-toplevel"], path)
    if code == 0 and out:
        return Path(out).resolve(), True
    return path.resolve(), False


def git_value(repo: Path, args: list[str], default: str = "") -> str:
    code, out = run(["git", *args], repo)
    return out if code == 0 else default


def read_text(path: Path, max_chars: int = 8000) -> str:
    if not path.exists():
        return ""
    text = path.read_text(encoding="utf-8", errors="ignore")
    return text if len(text) <= max_chars else text[:max_chars] + "\n\n[truncated]"


def latest_checkpoint(memory: Path) -> Path | None:
    checkpoints = memory / "checkpoints"
    if not checkpoints.exists():
        return None
    files = sorted(checkpoints.glob("*.md"), key=lambda p: p.stat().st_mtime, reverse=True)
    return files[0] if files else None


def main() -> int:
    parser = argparse.ArgumentParser(description="Print project-memory context for session continuation.")
    parser.add_argument("--repo", default=".", help="Repository or project directory.")
    parser.add_argument("--full", action="store_true", help="Print longer memory files.")
    args = parser.parse_args()

    repo, is_git = resolve_repo(Path(args.repo).expanduser().resolve())
    memory = repo / ".project-memory"
    branch = git_value(repo, ["branch", "--show-current"], "not-a-git-repository") if is_git else "not-a-git-repository"
    remote = git_value(repo, ["remote", "get-url", "origin"], "no-origin-remote") if is_git else "no-git"
    status = git_value(repo, ["status", "--short"], "") if is_git else ""
    latest = latest_checkpoint(memory)

    print("# Project Context Restore")
    print()
    print(f"Repository root: {repo}")
    print(f"Git repository: {'yes' if is_git else 'no'}")
    print(f"Branch: {branch or 'unknown'}")
    print(f"Origin remote: {remote or 'no-origin-remote'}")
    print(f"GitHub remote detected: {'yes' if 'github.com' in (remote or '').lower() or (remote or '').startswith('git@github.com:') else 'no'}")
    print(f"Working tree: {'clean' if not status.strip() else 'changes-present'}")
    if status.strip():
        print("\n## Git Status")
        print("```text")
        print(status)
        print("```")

    if not memory.exists():
        print("\nNo .project-memory directory found. Create the first checkpoint before relying on cross-session continuity.")
        return 0

    current = memory / "current-context.md"
    next_actions = memory / "next-actions.md"
    decisions = memory / "decisions.md"
    bugs = memory / "bugs-and-fixes.md"

    print("\n## Current Context")
    print(read_text(current, 12000 if args.full else 6000) or "No current-context.md found.")

    if latest:
        print("\n## Latest Checkpoint")
        print(f"Path: {latest}")
        print(read_text(latest, 12000 if args.full else 6000))
    else:
        print("\nNo checkpoint snapshots found.")

    print("\n## Next Actions")
    print(read_text(next_actions, 4000) or "No next-actions.md found.")

    if args.full:
        print("\n## Decisions")
        print(read_text(decisions, 8000) or "No decisions.md found.")
        print("\n## Bugs and Fixes")
        print(read_text(bugs, 8000) or "No bugs-and-fixes.md found.")

    print("\n## Resume Recommendation")
    print("Continue from the first concrete item in Next Actions, unless the user provides newer instructions. If the repository has changes, inspect them before editing.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
