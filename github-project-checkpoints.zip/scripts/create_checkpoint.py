#!/usr/bin/env python3
"""Create an intelligent project checkpoint under .project-memory/."""

from __future__ import annotations

import argparse
import os
import re
import subprocess
import sys
import unicodedata
from datetime import datetime
from pathlib import Path
from typing import Iterable

EXCLUDE_DIRS = {
    ".git", "node_modules", ".venv", "venv", "env", "dist", "build", "coverage",
    ".next", ".nuxt", ".cache", "__pycache__", ".pytest_cache", ".mypy_cache",
}
SECRET_PATTERNS = [
    re.compile(r"(?i)(api[_-]?key|secret|token|password|passwd|private[_-]?key)\s*[:=]\s*[^\s]+"),
    re.compile(r"AKIA[0-9A-Z]{16}"),
    re.compile(r"-----BEGIN (RSA |OPENSSH |EC |DSA )?PRIVATE KEY-----"),
]


def run(cmd: list[str], cwd: Path) -> tuple[int, str]:
    try:
        proc = subprocess.run(cmd, cwd=str(cwd), text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, check=False)
        return proc.returncode, proc.stdout.strip()
    except FileNotFoundError:
        return 127, f"command not found: {cmd[0]}"


def git_value(repo: Path, args: list[str], default: str = "") -> str:
    code, out = run(["git", *args], repo)
    return out if code == 0 else default


def resolve_repo(path: Path) -> tuple[Path, bool]:
    code, out = run(["git", "rev-parse", "--show-toplevel"], path)
    if code == 0 and out:
        return Path(out).resolve(), True
    return path.resolve(), False


def slugify(text: str) -> str:
    text = text.strip().lower() or "checkpoint"
    text = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode("ascii")
    text = re.sub(r"[^a-z0-9]+", "-", text)
    text = text.strip("-")
    return (text[:60] or "checkpoint").strip("-")


def append_lines(path: Path, heading: str, lines: Iterable[str], timestamp: str) -> None:
    clean = [line.strip() for line in lines if line and line.strip()]
    if not clean:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(f"\n## {timestamp}\n\n")
        f.write(f"**{heading}:**\n\n")
        for line in clean:
            f.write(f"- {line}\n")


def status_files(status: str) -> list[str]:
    files: list[str] = []
    for line in status.splitlines():
        if not line.strip():
            continue
        item = line[3:] if len(line) > 3 else line.strip()
        if " -> " in item:
            item = item.split(" -> ", 1)[1]
        files.append(item.strip())
    return files


def is_text_file(path: Path) -> bool:
    try:
        data = path.read_bytes()[:4096]
    except OSError:
        return False
    return b"\0" not in data


def scan_secret_warnings(repo: Path, files: list[str]) -> list[str]:
    warnings: list[str] = []
    suspicious_names = [".env", "id_rsa", "id_ed25519", "credentials", "secrets", "service-account"]
    for rel in files[:200]:
        lower = rel.lower()
        if any(name in lower for name in suspicious_names):
            warnings.append(f"Suspicious filename changed: {rel}")
            continue
        path = (repo / rel).resolve()
        try:
            path.relative_to(repo)
        except ValueError:
            continue
        if not path.exists() or not path.is_file() or not is_text_file(path):
            continue
        try:
            text = path.read_text(encoding="utf-8", errors="ignore")[:20000]
        except OSError:
            continue
        for pattern in SECRET_PATTERNS:
            if pattern.search(text):
                warnings.append(f"Possible secret pattern in: {rel}")
                break
    return warnings


def make_repository_map(repo: Path, max_entries: int = 220) -> str:
    entries: list[str] = []
    for root, dirs, files in os.walk(repo):
        root_path = Path(root)
        dirs[:] = sorted([d for d in dirs if d not in EXCLUDE_DIRS and not d.startswith(".")])
        rel_root = root_path.relative_to(repo)
        depth = 0 if str(rel_root) == "." else len(rel_root.parts)
        if depth > 3:
            dirs[:] = []
            continue
        indent = "  " * depth
        label = "." if str(rel_root) == "." else rel_root.name
        entries.append(f"{indent}- {label}/")
        for file_name in sorted(files):
            if file_name.startswith(".") and file_name not in {".gitignore"}:
                continue
            entries.append(f"{indent}  - {file_name}")
            if len(entries) >= max_entries:
                entries.append("  - ...")
                return "\n".join(entries)
        if len(entries) >= max_entries:
            entries.append("  - ...")
            return "\n".join(entries)
    return "\n".join(entries)


def md_list(items: list[str], fallback: str = "Not recorded.") -> str:
    clean = [item.strip() for item in items if item and item.strip()]
    if not clean:
        return fallback
    return "\n".join(f"- {item}" for item in clean)


def main() -> int:
    parser = argparse.ArgumentParser(description="Create a project-memory checkpoint for a Git/GitHub repository.")
    parser.add_argument("--repo", default=".", help="Repository or project directory.")
    parser.add_argument("--summary", default="Project checkpoint saved.", help="Concise checkpoint summary.")
    parser.add_argument("--objective", default="Continue the active project task.", help="Current project objective.")
    parser.add_argument("--next", action="append", default=[], help="Next action. May be repeated.")
    parser.add_argument("--decision", action="append", default=[], help="Decision to preserve. May be repeated.")
    parser.add_argument("--discovery", action="append", default=[], help="Discovery to preserve. May be repeated.")
    parser.add_argument("--bugfix", action="append", default=[], help="Bug fix or debugging note. May be repeated.")
    parser.add_argument("--risk", action="append", default=[], help="Risk or open question. May be repeated.")
    parser.add_argument("--commit", action="store_true", help="Create a local git commit for .project-memory files only.")
    parser.add_argument("--commit-message", default="checkpoint(project): save project memory", help="Commit message when --commit is used.")
    args = parser.parse_args()

    start = Path(args.repo).expanduser().resolve()
    repo, is_git = resolve_repo(start)
    memory = repo / ".project-memory"
    checkpoints = memory / "checkpoints"
    checkpoints.mkdir(parents=True, exist_ok=True)

    now = datetime.now().astimezone()
    timestamp = now.strftime("%Y-%m-%d %H:%M:%S %z")
    file_stamp = now.strftime("%Y%m%d-%H%M%S")
    slug = slugify(args.summary)

    branch = git_value(repo, ["branch", "--show-current"], "not-a-git-repository") if is_git else "not-a-git-repository"
    commit_hash = git_value(repo, ["rev-parse", "--short", "HEAD"], "no-commit") if is_git else "no-git"
    remote = git_value(repo, ["remote", "get-url", "origin"], "no-origin-remote") if is_git else "no-git"
    status = git_value(repo, ["status", "--short"], "") if is_git else ""
    files = status_files(status)
    warnings = scan_secret_warnings(repo, files) if files else []
    github_detected = "github.com" in remote.lower() or remote.startswith("git@github.com:")
    working_tree_state = "clean" if not status.strip() else "changes-present"
    repo_map = make_repository_map(repo)

    checkpoint_path = checkpoints / f"{file_stamp}-{slug}.md"
    changed_files_md = md_list(files, "No changed files reported by git status.")
    decisions_md = md_list(args.decision)
    discoveries_md = md_list(args.discovery)
    bugfixes_md = md_list(args.bugfix)
    risks_md = md_list(args.risk + warnings, "No risks recorded.")
    next_md = md_list(args.next, "Ask the user for the next development objective or continue from the latest unfinished task.")

    checkpoint_text = f"""# Project Checkpoint: {slug}

| Field | Value |
|---|---|
| Timestamp | {timestamp} |
| Repository Root | `{repo}` |
| Branch | `{branch}` |
| Commit | `{commit_hash}` |
| Remote | `{remote}` |
| GitHub Remote Detected | {"yes" if github_detected else "no"} |
| Working Tree | {working_tree_state} |

## Summary

{args.summary}

## Active Objective

{args.objective}

## Changed Files

{changed_files_md}

## Decisions

{decisions_md}

## Discoveries

{discoveries_md}

## Bugs and Fixes

{bugfixes_md}

## Risks and Secret-Scan Warnings

{risks_md}

## Next Actions

{next_md}

## Resume Notes

Read `.project-memory/current-context.md`, then this checkpoint, then inspect `git status --short`. Continue with the first actionable item in **Next Actions** unless the user gives newer instructions.
"""
    checkpoint_path.write_text(checkpoint_text, encoding="utf-8")

    current_context = f"""# Current Project Context

| Field | Value |
|---|---|
| Last Updated | {timestamp} |
| Repository Root | `{repo}` |
| Branch | `{branch}` |
| Commit | `{commit_hash}` |
| Remote | `{remote}` |
| GitHub Remote Detected | {"yes" if github_detected else "no"} |
| Working Tree | {working_tree_state} |
| Latest Checkpoint | `{checkpoint_path.relative_to(repo)}` |

## Active Objective

{args.objective}

## Current State

{args.summary}

## Important Files and Areas

{changed_files_md}

## Recent Progress

See `{checkpoint_path.relative_to(repo)}` and `.project-memory/timeline.md`.

## Decisions to Preserve

{decisions_md}

## Known Bugs, Fixes, and Risks

{bugfixes_md}

{risks_md}

## Next Actions

{next_md}

## Resume Instruction for Next Session

Start by running `python /home/ubuntu/skills/github-project-checkpoints/scripts/restore_context.py --repo .`, read this file, inspect the latest checkpoint, then continue with the first item in **Next Actions** unless the user gives newer instructions.
"""
    (memory / "current-context.md").write_text(current_context, encoding="utf-8")
    (memory / "repository-map.md").write_text(f"# Repository Map\n\nUpdated: {timestamp}\n\n```text\n{repo_map}\n```\n", encoding="utf-8")

    with (memory / "timeline.md").open("a", encoding="utf-8") as f:
        f.write(f"\n## {timestamp}\n\n")
        f.write(f"- **Checkpoint:** `{checkpoint_path.relative_to(repo)}`\n")
        f.write(f"- **Branch:** `{branch}`\n")
        f.write(f"- **Summary:** {args.summary}\n")
        if args.next:
            f.write(f"- **Next:** {'; '.join(args.next)}\n")

    (memory / "next-actions.md").write_text(f"# Next Actions\n\nUpdated: {timestamp}\n\n{next_md}\n", encoding="utf-8")
    append_lines(memory / "decisions.md", "Decisions", args.decision, timestamp)
    append_lines(memory / "bugs-and-fixes.md", "Bugs and fixes", args.bugfix, timestamp)

    committed = False
    if args.commit:
        if not is_git:
            print("WARN: --commit requested, but this directory is not a Git repository.")
        elif warnings:
            print("WARN: Commit skipped because possible secret warnings were detected:")
            for warning in warnings:
                print(f"- {warning}")
        else:
            run(["git", "add", ".project-memory"], repo)
            code, out = run(["git", "commit", "-m", args.commit_message], repo)
            committed = code == 0
            if out:
                print(out)

    print(f"CHECKPOINT_PATH={checkpoint_path}")
    print(f"REPO_ROOT={repo}")
    print(f"BRANCH={branch}")
    print(f"GITHUB_REMOTE_DETECTED={'yes' if github_detected else 'no'}")
    print(f"WORKING_TREE={working_tree_state}")
    print(f"SECRET_WARNINGS={len(warnings)}")
    print(f"LOCAL_COMMIT_CREATED={'yes' if committed else 'no'}")
    if warnings:
        print("WARNINGS:")
        for warning in warnings:
            print(f"- {warning}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
