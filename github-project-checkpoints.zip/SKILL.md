---
name: github-project-checkpoints
description: Intelligent project checkpoints and GitHub repository memory. Use when working in a Git or GitHub repository, continuing a project across sessions, saving project context, creating game-save-like checkpoints, organizing project memory, documenting progress, decisions, discoveries, bugs, fixes, next steps, commits, branches, or preparing safe git commit and push workflows.
---

# GitHub Project Checkpoints

Use this skill to preserve project continuity in Git/GitHub repositories through **checkpoint files** that behave like advanced game saves. A checkpoint records the current project state, active objective, branch, changed files, decisions, discoveries, bugs, fixes, risks, and next actions so a future Manus session can continue from the same point without losing context.

## Operating Principle

A normal Git commit preserves code. A project checkpoint preserves **working memory**. Always treat commits and checkpoints as complementary: commits capture file changes, while `.project-memory/` captures why the changes exist, what remains unfinished, and how to resume work.

This skill cannot run continuously in the background simply because it is installed. Instead, when this skill is triggered by a compatible task, immediately inspect the current repository and use the checkpoint workflow at session start, before major transitions, before risky edits, after bug fixes, before commits, and at session end.

## Repository Detection

At the beginning of a compatible project task, determine whether the current working directory is a Git repository connected to GitHub.

Run these checks from the project directory:

```bash
git rev-parse --show-toplevel
git branch --show-current
git remote -v
git status --short
```

If a GitHub remote exists, also check whether the GitHub CLI is available and authenticated:

```bash
gh auth status
```

If no repository is detected, ask whether the user wants to initialize Git or continue without GitHub integration. If a repository is detected but no GitHub remote exists, keep local checkpoints and explain that remote continuity requires a GitHub remote.

## Memory Directory

Maintain this directory at the repository root:

```text
.project-memory/
├── current-context.md
├── timeline.md
├── next-actions.md
├── repository-map.md
├── decisions.md
├── bugs-and-fixes.md
└── checkpoints/
    └── YYYYMMDD-HHMMSS-slug.md
```

Never place secrets in `.project-memory/`. Do not record API keys, passwords, OAuth tokens, cookies, private keys, `.env` values, production credentials, customer data, or proprietary data unrelated to the project task.

## Startup Continuity Workflow

When asked to continue a project, resume a previous task, inspect repository memory, or work in a GitHub-connected project, first run:

```bash
python /home/ubuntu/skills/github-project-checkpoints/scripts/restore_context.py --repo .
```

Read the printed summary and then inspect the referenced files under `.project-memory/`. Use the latest checkpoint and `current-context.md` as the authoritative project memory unless the user provides newer instructions.

## Checkpoint Workflow

Create a checkpoint whenever one of these events occurs: starting a new phase, completing a meaningful feature, fixing a bug, discovering important architecture, before a risky refactor, before commit, after commit, before ending the session, or whenever the user asks to save progress.

Use the deterministic script:

```bash
python /home/ubuntu/skills/github-project-checkpoints/scripts/create_checkpoint.py \
  --repo . \
  --summary "Concise summary of what changed" \
  --next "Specific next action" \
  --decision "Important decision or empty if none" \
  --bugfix "Bug fixed or empty if none"
```

The script updates `.project-memory/current-context.md`, appends to `timeline.md`, refreshes repository map files, and creates a timestamped snapshot under `.project-memory/checkpoints/`.

## Commit and Push Policy

Before committing, ensure `.project-memory/` is updated. Use conventional commit style when possible:

```text
type(scope): concise description
```

Recommended types are `feat`, `fix`, `docs`, `refactor`, `test`, `chore`, and `checkpoint`. A checkpoint-only commit should use:

```text
checkpoint(project): save project memory after <milestone>
```

A `git push` publishes data to the remote repository. Before pushing, verify that no secrets or private data are included and ask the user for confirmation when the operation is sensitive or externally visible.

## Organization Duties

When this skill is active, keep the repository understandable for future sessions. Update `repository-map.md` after structural changes, append design decisions to `decisions.md`, document reproducible bugs and fixes in `bugs-and-fixes.md`, and keep `next-actions.md` concrete enough that another session can immediately continue.

## Output Expectations

When reporting to the user after using this skill, mention the checkpoint path, current branch, whether GitHub remote was detected, whether there are uncommitted changes, and the next recommended action. If a push is recommended, explain what would be pushed and ask for confirmation before publishing.

## Bundled Resources

Read `references/workflow.md` when a task requires more detailed operating conventions, commit strategy, or memory-file semantics. Use `templates/current-context.md` and `templates/checkpoint.md` as format references when manually editing checkpoint files. Use the bundled scripts for repeatable creation and restoration of project memory.
