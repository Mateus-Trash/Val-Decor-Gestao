# Workflow avançado de checkpoints de projeto

Esta referência detalha como operar a skill `github-project-checkpoints` em projetos reais. O objetivo é manter um repositório GitHub suficientemente autoexplicativo para que qualquer nova sessão consiga reconstruir contexto, entender decisões e continuar sem retrabalho.

## Ciclo recomendado

| Momento | Ação | Resultado esperado |
|---|---|---|
| Início da sessão | Executar `restore_context.py` e ler `.project-memory/current-context.md`. | Recuperar objetivo, estado atual, branch, pendências e último checkpoint. |
| Antes de editar | Verificar `git status`, branch, arquivos críticos e riscos. | Evitar sobrescrever trabalho existente ou editar fora da área correta. |
| Após descoberta importante | Criar checkpoint com `--decision` ou resumo de descoberta. | Preservar conhecimento que não aparece apenas no código. |
| Após bug fix | Criar checkpoint com `--bugfix`. | Registrar sintoma, causa provável e correção aplicada. |
| Antes de commit | Atualizar checkpoint e revisar segredos. | Garantir que memória e código estejam sincronizados. |
| Fim da sessão | Criar checkpoint final e preencher `next-actions.md`. | Permitir retomada exata em outra sessão. |

## Semântica dos arquivos

`current-context.md` deve conter a fotografia mais recente do projeto. Ele deve ser curto, porém suficiente para retomada. `timeline.md` é um log cronológico dos checkpoints. `next-actions.md` deve priorizar ações concretas, testáveis e ordenadas. `repository-map.md` descreve a estrutura atual e aponta arquivos críticos. `decisions.md` preserva decisões arquiteturais e razões. `bugs-and-fixes.md` registra falhas, causas, soluções e verificação.

## Regras de segurança

Antes de commit ou push, verificar se `.project-memory/` ou qualquer arquivo alterado contém segredos. Não versionar `.env`, tokens, cookies, chaves privadas, arquivos de credenciais, dumps sensíveis, logs com dados pessoais ou capturas contendo credenciais. Se houver dúvida, parar e pedir instrução ao usuário.

## Convenção de commits

Usar commits pequenos e explicativos. Quando o checkpoint acompanhar uma mudança de código, incluir `.project-memory/` no mesmo commit se ele documenta a mesma unidade de trabalho. Quando não houver mudança de código, usar um commit de checkpoint:

```text
checkpoint(project): save project memory after session
```

Quando o repositório estiver conectado ao GitHub e o usuário pedir publicação, primeiro apresentar o resumo do que será enviado e solicitar confirmação antes de executar `git push`.

## Retomada em nova sessão

A nova sessão deve iniciar pela restauração do contexto. Se houver divergência entre a memória do repositório e a instrução recente do usuário, a instrução do usuário tem prioridade, mas a diferença deve ser registrada em um novo checkpoint.
