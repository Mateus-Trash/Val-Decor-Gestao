# Project Checkpoint: {{slug}}

| Field | Value |
|---|---|
| Timestamp | {{timestamp}} |
| Project | {{project_name}} |
| Branch | {{branch}} |
| Commit | {{commit_hash}} |
| Remote | {{remote_url}} |
| Working Tree | {{working_tree_state}} |

## Summary

{{summary}}

## What Changed

{{changed_files}}

## Decisions

{{decisions}}

## Discoveries

{{discoveries}}

## Bugs and Fixes

{{bugfixes}}

## Risks and Open Questions

{{risks}}

## Next Actions

{{next_actions}}

## Resume Notes

{{resume_notes}}
