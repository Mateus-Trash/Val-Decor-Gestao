# Current Project Context

## Project Identity

| Field | Value |
|---|---|
| Project | {{project_name}} |
| Repository Root | {{repo_root}} |
| Branch | {{branch}} |
| GitHub Remote | {{remote_url}} |
| Last Updated | {{timestamp}} |

## Active Objective

{{active_objective}}

## Current State

{{current_state}}

## Important Files and Areas

{{important_files}}

## Recent Progress

{{recent_progress}}

## Decisions to Preserve

{{decisions}}

## Known Bugs, Fixes, and Risks

{{bugs_and_risks}}

## Next Actions

{{next_actions}}

## Resume Instruction for Next Session

Start by reading this file, then read the latest file under `.project-memory/checkpoints/`, inspect `git status --short`, and continue with the first item in **Next Actions** unless the user gives newer instructions.
